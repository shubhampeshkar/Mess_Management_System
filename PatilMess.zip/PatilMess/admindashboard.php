
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

</head>
  <body>

  <?php 
include 'header2.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  

<br><br><br><br><br><br>




<div class="container text-center">
  <div class="row">
    <div class="col">
    
    </div>
    <div class="col">
      
    <div class="card text-bg-dark mb-3"  style="width: 75rem;  height: 32rem;">
  
  <div class="card-body">
    <br>
<h2>ADMIN-DASHBOARD</h2> 

<hr>
<br><br>


<div class="container text-center">
  <div class="row">
    <div class="col">
    <div class="alert alert-warning" role="alert">
    <a class="btn btn-light btn-lg" href="updatemenu.php" role="button">Update Menu</a> &nbsp;&nbsp; &nbsp;&nbsp;

</div>
    </div>
    <div class="col">
    <div class="alert alert-warning" role="alert">
  
    <a class="btn btn-warning btn-lg" href="regularuserlist.php" role="button">Regular User List</a>&nbsp;&nbsp; &nbsp;&nbsp; 

</div>
    </div>
    <div class="col">
    <div class="alert alert-warning" role="alert">
  
    <a class="btn btn-light btn-lg" href="regularuserplandetails.php" role="button">User Plan Details</a>&nbsp;&nbsp; &nbsp;&nbsp;

</div>
    </div>
  </div>
</div>




<div class="container text-center">
  <div class="row">
    <div class="col">
    <div class="alert alert-warning" role="alert">
  
    <a class="btn btn-warning btn-lg" href="abc.php" role="button">Attendence</a> &nbsp;&nbsp; &nbsp;&nbsp;

</div>
    </div>
    <div class="col">
    <div class="alert alert-warning" role="alert">
  
    <a class="btn btn-light btn-lg" href="regularuserpaymenttransaction.php" role="button">Payment Transaction</a> &nbsp;&nbsp; &nbsp;&nbsp;

</div>
    </div>
    <div class="col">
    <div class="alert alert-warning" role="alert">
    <a class="btn btn-warning btn-lg" href="recentorders.php" role="button">Recent Orders</a><br>
    
</div>
    </div>
  </div>
</div>


<div class="container text-center">
  <div class="row">
    <div class="col">
    <div class="alert alert-warning" role="alert">
    <a class="btn btn-light btn-lg" href="guestuserpayments.php" role="button">Guest Users Payments</a> &nbsp;&nbsp; &nbsp;&nbsp;

</div>
    </div>
    <div class="col">
    <div class="alert alert-warning" role="alert">
  
    <a class="btn btn-warning btn-lg" href="addnotice.php" role="button">Notice</a>&nbsp;&nbsp; &nbsp;&nbsp; 

</div>
    </div>
    <div class="col">
    <div class="alert alert-warning" role="alert">
  
    <a class="btn btn-light btn-lg" href="viewmessage.php" role="button">Message</a>&nbsp;&nbsp; &nbsp;&nbsp;

</div>
    </div>
  </div>
</div>













 
  
  </div>
</div>

    </div>
    <div class="col">
      
    </div>
  </div>
</div>

</body>
</html>